# Commercial End-User License Agreement (EULA)

**Product**: Rest
**Licensor**: LumicorePro Digital Products

### 1. Grant of License

Upon purchase of Rest, you are granted a non-exclusive, worldwide commercial license to use, modify, and build commercial applications, client websites, or SaaS products with this template.

### 2. Allowed Uses

- Deploying unlimited commercial client websites.
- Building proprietary SaaS platforms that charge end-users.
- Modifying brand styling, colors, logo, and features.

### 3. Restrictions

- You may NOT resell, redistribute, or open-source the raw unmodified source code files as a competing template on any marketplace.
